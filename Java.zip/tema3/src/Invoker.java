import java.io.PrintWriter;
import java.util.*;

public class Invoker {

    private List<Command> commandList = new ArrayList<Command>();

    private static Invoker ourInstance = new Invoker();

    public static Invoker getInstance() {
        return ourInstance;
    }

    private Invoker() {}

    public List<Command> get_commandList() {

        return commandList;
    }

    public void takeCommand(Command command) {

        commandList.add(command);
    }

    public void placeCommands(PrintWriter out, PrintWriter err) throws CloneNotSupportedException {

        int index_command = 0;

        for (Command command: commandList) {

            index_command++;

            out.printf("%d\n", index_command);
            err.printf("%d\n", index_command);

            command.execute();
        }

        commandList.clear();
    }
}