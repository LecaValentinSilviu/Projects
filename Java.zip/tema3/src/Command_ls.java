import java.io.PrintWriter;

public class Command_ls implements Command {

    private Commands commands;
    String arg1, arg2;
    Directory current_d;
    PrintWriter out, err;

    public Command_ls(Commands commands, String arg1, String arg2, Directory current_d, PrintWriter out, PrintWriter err) {

        this.commands = commands;
        this.arg1 = arg1;
        this.arg2 = arg2;
        this.current_d = current_d;
        this.out = out;
        this.err = err;
    }

    public void execute() {

        commands.ls(arg1, arg2, current_d, out, err); // argumente
    }

    public void change_current_directory(Directory current_d) {

        this.current_d = current_d;
    }
}
