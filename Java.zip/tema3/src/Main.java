import java.io.*;
import java.util.*;

public class Main {

    public static void main(String[] args) throws Exception {

        Directory root = new Directory("/", null);

        Directory current_directory = root;

        Commands commands = Commands.getInstance();

        Command command;

        Factory factory = Factory.getInstance();

        Invoker invoker = Invoker.getInstance();

        File input_file = new File(args[0]); // deschidere fisier citire
        Scanner sc = new Scanner(input_file);

        FileWriter output_fileWriter = new FileWriter(args[1]);
        PrintWriter output_printWriter = new PrintWriter(output_fileWriter);

        FileWriter error_fileWriter = new FileWriter(args[2]);
        PrintWriter error_printWriter = new PrintWriter(error_fileWriter);

        factory.initialize(commands, current_directory, output_printWriter, error_printWriter); // !!!!!!!!!!!!!!!!!!

        String line;

        while (sc.hasNextLine()) {

            line = sc.nextLine();

            System.out.println(line);

            command = factory.createCommand(line); // !!!!!!!!!!!!!!!!

            invoker.takeCommand(command);
        }

        invoker.placeCommands(output_printWriter, error_printWriter);

        output_printWriter.close();
        error_printWriter.close();
    }
}
