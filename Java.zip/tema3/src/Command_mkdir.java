import java.io.PrintWriter;

public class Command_mkdir implements Command {

    private Commands commands;
    String folder_path;
    Directory current_d;
    PrintWriter err;

    public Command_mkdir(Commands commands, String folder_path, Directory current_d, PrintWriter err) {

        this.commands = commands;
        this.folder_path = folder_path;
        this.current_d = current_d;
        this.err = err;
    }

    public void execute() {

        commands.mkdir(folder_path, current_d, err); // argumente
    }

    public void change_current_directory(Directory current_d) {

        this.current_d = current_d;
    }
}
