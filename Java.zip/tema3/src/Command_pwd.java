import java.io.PrintWriter;

public class Command_pwd implements Command {

    private Commands commands;
    Directory current_d;
    PrintWriter out;

    public Command_pwd(Commands commands, Directory current_d, PrintWriter out) {

        this.commands = commands;
        this.current_d = current_d;
        this.out = out;
    }

    public void execute() {

        commands.pwd(current_d, out); // argumente
    }

    public void change_current_directory(Directory current_d) {

        this.current_d = current_d;
    }
}
