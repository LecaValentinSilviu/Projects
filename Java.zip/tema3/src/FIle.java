public class FIle implements Cloneable {

    String name;
    Directory parent;

    FIle(String name, Directory parent) {

        this.name = name;
        this.parent = parent;
    }

    public FIle clone() throws CloneNotSupportedException {
        return (FIle) super.clone();
    }
}
