import java.io.PrintWriter;
import java.util.*;

public class Commands {

    private static Commands ourInstance = new Commands();

    public static Commands getInstance() {
        return ourInstance;
    }

    private Commands() {}

    public String get_path(Directory current_d) {

        Directory d = current_d;

        if (d.name.equals("/")) {

            return "/";
        }
        else {

            List<String> list = new ArrayList<String>();

            while (!d.name.equals("/")) {

                list.add(d.name);

                d = d.parent;
            }

            StringBuilder path = new StringBuilder();

            Collections.reverse(list);

            for (String s: list) {

                path.append('/').append(s);
            }

            return path.toString();
        }
    }

    public void dfs(Directory current_d, PrintWriter out) {

        TreeSet<String> to_list = new TreeSet<String>();
        String current_path = get_path(current_d);

        out.printf("%s:\n", current_path);

        for (Object o: current_d.children) {

            if (o instanceof Directory) {

                to_list.add(((Directory) o).name);
            }
            else {
                to_list.add(((FIle) o).name);
            }
        }

        Iterator iterator = to_list.iterator();

        if (current_d.name.equals("/")) {

            for (String s: to_list) {

                out.printf("/%s ", s);
            }
        }
        else {

            for (String s: to_list) {

                out.printf("%s/%s ", current_path, s);
            }
        }

        out.printf("\n\n");

        for (String s: to_list) {

            for (Object o: current_d.children) {

                if (o instanceof Directory) {

                    if (((Directory) o).name.equals(s)) {

                        dfs((Directory) o, out);
                        break;
                    }
                }
            }
        }
    }

    public void ls(String arg1, String arg2, Directory current_d, PrintWriter out, PrintWriter err) {

       /* String[] token;
        boolean gasit;
        Directory d = current_d;
        int i;
        TreeSet<String> to_list = new TreeSet<String>();
        String current_path = get_path(current_d);
        */
        if (arg2 == null) {

            if (arg1 == null) {

                TreeSet<String> to_list = new TreeSet<String>();
                String current_path = get_path(current_d);

                out.printf("%s:\n", current_path);

                for (Object o: current_d.children) {

                    if (o instanceof Directory) {

                        to_list.add(((Directory) o).name);
                    }
                    else {
                        to_list.add(((FIle) o).name);
                    }
                }

                if (current_d.name.equals("/")) {

                    for (String s: to_list) {

                        out.printf("/%s ", s);
                    }
                }
                else {

                    for (String s: to_list) {

                        out.printf("%s/%s ", current_path, s);
                    }
                }

                out.printf("\n\n");
            }
            else if (arg1.equals("-R")) {

                dfs(current_d, out);
            }
            else {

                String[] token, token2;
                boolean gasit;
                Directory d = current_d;
                int i;

                if (arg1.charAt(0) == '/') {

                    while (!d.name.equals("/")) {

                        d = d.parent;
                    }
                }

                token2 = arg1.split("/");

                if (arg1.charAt(0) == '/' && token2.length > 0) {

                    token = new String[token2.length - 1];

                    for (i = 0; i < token.length; i++) {

                        token[i] = token2[i + 1];
                    }
                }
                else {

                    token = new String[token2.length];

                    for (i = 0; i < token.length; i++) {

                        token[i] = token2[i];
                    }
                }

                for (i = 0; i < token.length; i++) {

                    if (token[i].equals(".")) {

                        d = d;
                    }
                    else if (token[i].equals("..")) {

                        if (d.name.equals("/")) {

                            err.printf("ls: %s: No such directory\n", arg1);

                            return;
                        }
                        else {

                            d = d.parent;
                        }
                    }
                    else {

                        gasit = false;

                        for (Object o: d.children) {

                            if (o instanceof Directory) {

                                if (((Directory) o).name.equals(token[i])) {

                                    gasit = true;
                                    d = (Directory) o;
                                    break;
                                }
                            }
                        }

                        if (!gasit) {

                            err.printf("ls: %s: No such directory\n", arg1);

                            return;
                        }
                    }
                }

                TreeSet<String> to_list = new TreeSet<String>();
                String current_path = get_path(d);

                out.printf("%s:\n", current_path);

                for (Object o: d.children) {

                    if (o instanceof Directory) {

                        to_list.add(((Directory) o).name);
                    }
                    else {
                        to_list.add(((FIle) o).name);
                    }
                }

                if (d.name.equals("/")) {

                    for (String s: to_list) {

                        out.printf("/%s ", s);
                    }
                }
                else {

                    for (String s: to_list) {

                        out.printf("%s/%s ", current_path, s);
                    }
                }

                out.printf("\n\n");
            }
        }
        else {///////////////////////////////////////////////////////////////

            if (arg2.equals("-R")) {

                String[] token, token2;
                boolean gasit;
                Directory d = current_d;
                int i;

                if (arg1.charAt(0) == '/') {

                    while (!d.name.equals("/")) {

                        d = d.parent;
                    }
                }

                token2 = arg1.split("/");

                if (arg1.charAt(0) == '/' && token2.length > 0) {

                    token = new String[token2.length - 1];

                    for (i = 0; i < token.length; i++) {

                        token[i] = token2[i + 1];
                    }
                }
                else {

                    token = new String[token2.length];

                    for (i = 0; i < token.length; i++) {

                        token[i] = token2[i];
                    }
                }

                for (i = 0; i < token.length; i++) {

                    if (token[i].equals(".")) {

                        d = d;
                    }
                    else if (token[i].equals("..")) {

                        if (d.name.equals("/")) {

                            err.printf("ls: %s: No such directory\n", arg1);

                            return;
                        }
                        else {

                            d = d.parent;
                        }
                    }
                    else {

                        gasit = false;

                        for (Object o: d.children) {

                            if (o instanceof Directory) {

                                if (((Directory) o).name.equals(token[i])) {

                                    gasit = true;
                                    d = (Directory) o;
                                    break;
                                }
                            }
                        }

                        if (!gasit) {

                            err.printf("ls: %s: No such directory\n", arg1);

                            return;
                        }
                    }
                }

                dfs(d, out);
            }

            if (arg1.equals("-R")) {

                String[] token, token2;
                boolean gasit;
                Directory d = current_d;
                int i;

                if (arg2.charAt(0) == '/') {

                    while (!d.name.equals("/")) {

                        d = d.parent;
                    }
                }

                token2 = arg2.split("/");

                if (arg2.charAt(0) == '/' && token2.length > 0) {

                    token = new String[token2.length - 1];

                    for (i = 0; i < token.length; i++) {

                        token[i] = token2[i + 1];
                    }
                }
                else {

                    token = new String[token2.length];

                    for (i = 0; i < token.length; i++) {

                        token[i] = token2[i];
                    }
                }

                for (i = 0; i < token.length; i++) {

                    if (token[i].equals(".")) {

                        d = d;
                    }
                    else if (token[i].equals("..")) {

                        if (d.name.equals("/")) {

                            err.printf("ls: %s: No such directory\n", arg2);

                            return;
                        }
                        else {

                            d = d.parent;
                        }
                    }
                    else {

                        gasit = false;

                        for (Object o: d.children) {

                            if (o instanceof Directory) {

                                if (((Directory) o).name.equals(token[i])) {

                                    gasit = true;
                                    d = (Directory) o;
                                    break;
                                }
                            }
                        }

                        if (!gasit) {

                            err.printf("ls: %s: No such directory\n", arg2);

                            return;
                        }
                    }
                }

                dfs(d, out);
            }
        }
    }

    public void pwd(Directory current_d, PrintWriter out) {

        out.printf("%s\n", get_path(current_d));
    }

    public void cd(String path, Directory current_d, PrintWriter err) {

        String[] token, token2;
        boolean gasit;
        Directory d = current_d;
        int i;

        if (path.charAt(0) == '/') {

            while (!d.name.equals("/")) {

                d = d.parent;
            }
        }

        token2 = path.split("/");

        if (path.charAt(0) == '/' && token2.length > 0) {

            token = new String[token2.length - 1];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i + 1];
            }
        }
        else {

            token = new String[token2.length];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i];
            }
        }

        for (i = 0; i < token.length; i++) {

            if (token[i].equals(".")) {

                d = d;
            }
            else if (token[i].equals("..")) {

                if (d.name.equals("/")) {

                    err.printf("cd: %s: No such directory\n", path);

                    return;
                }
                else {

                    d = d.parent;
                }
            }
            else {

                gasit = false;

                for (Object o: d.children) {

                    if (o instanceof Directory) {

                        if (((Directory) o).name.equals(token[i])) {

                            gasit = true;
                            d = (Directory) o;
                            break;
                        }
                    }
                }

                if (!gasit) {

                    err.printf("cd: %s: No such directory\n", path);

                    return;
                }
            }
        }

        for (Command command: Invoker.getInstance().get_commandList()) {

            command.change_current_directory(d);
        }
    }

    public void cp(String source, String dest_folder, Directory current_d, PrintWriter err)
            throws CloneNotSupportedException {

        String[] token, token2;
        boolean gasit;
        Directory d1 = current_d, d2 = current_d;
        int i;

        if (source.charAt(0) == '/') {

            while (!d1.name.equals("/")) {

                d1 = d1.parent;
            }
        }

        token2 = source.split("/");

        if (source.charAt(0) == '/' && token2.length > 0) {

            token = new String[token2.length - 1];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i + 1];
            }
        }
        else {

            token = new String[token2.length];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i];
            }
        }

        for (i = 0; i < token.length - 1; i++) {

            if (token[i].equals(".")) {

                d1 = d1;
            }
            else if (token[i].equals("..")) {

                if (d1.name.equals("/")) {

                    err.printf("cp: cannot copy %s: No such file or directory\n", source);

                    return;
                }
                else {

                    d1 = d1.parent;
                }
            }
            else {

                gasit = false;

                for (Object o: d1.children) {

                    if (o instanceof Directory) {

                        if (((Directory) o).name.equals(token[i])) {

                            gasit = true;
                            d1 = (Directory) o;
                            break;
                        }
                    }
                }

                if (!gasit) {

                    err.printf("cp: cannot copy %s: No such file or directory\n", source);

                    return;
                }
            }
        }

        Directory is_directory = null;
        FIle is_FIle = null;
        gasit = false;

        for (Object o: d1.children) {

            if (o instanceof Directory) {

                is_directory = (Directory) o;

                if (is_directory.name.equals(token[token.length - 1])) {

                    gasit = true;
                    is_FIle = null;
                    break;
                }
            }
            else {

                is_FIle = (FIle) o;

                if (is_FIle.name.equals(token[token.length - 1])) {

                    gasit = true;
                    is_directory = null;
                    break;
                }
            }
        }

        if (!gasit) {

            err.printf("cp: cannot copy %s: No such file or directory\n", source);

            return;
        }

        if (dest_folder.charAt(0) == '/') {

            while (!d2.name.equals("/")) {

                d2 = d2.parent;
            }
        }

        token2 = dest_folder.split("/");

        if (dest_folder.charAt(0) == '/' && token2.length > 0) {

            token = new String[token2.length - 1];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i + 1];
            }
        }
        else {

            token = new String[token2.length];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i];
            }
        }

        for (i = 0; i < token.length; i++) {

            if (token[i].equals(".")) {

                d2 = d2;
            }
            else if (token[i].equals("..")) {

                if (d2.name.equals("/")) {

                    err.printf("cp: cannot copy into %s: No such directory\n", dest_folder);

                    return;
                }
                else {

                    d2 = d2.parent;
                }
            }
            else {

                gasit = false;

                for (Object o: d2.children) {

                    if (o instanceof Directory) {

                        if (((Directory) o).name.equals(token[i])) {

                            gasit = true;
                            d2 = (Directory) o;
                            break;
                        }
                    }
                }

                if (!gasit) {

                    err.printf("cp: cannot copy into %s: No such directory\n", dest_folder);

                    return;
                }
            }
        }

        boolean inclus = false;

        for (Object o: d2.children) {

            if (o instanceof Directory) {

                if (is_directory != null) {

                    if (((Directory) o).name.equals(is_directory.name)) {

                        inclus = true;
                        break;
                    }
                }
                else {

                    if (((Directory) o).name.equals(is_FIle.name)) {

                        inclus = true;
                        break;
                    }
                }
            }
            else {

                if (is_directory != null) {

                    if (((FIle) o).name.equals(is_directory.name)) {

                        inclus = true;
                        break;
                    }
                }
                else {

                    if (((FIle) o).name.equals(is_FIle.name)) {

                        inclus = true;
                        break;
                    }
                }
            }
        }

        if (inclus) {

            err.printf("cp: cannot copy %s: Node exists at destination\n", source);
        }
        else {

            if (is_directory != null) {

                Directory directory_clone = is_directory.clone();

                d2.children.add(directory_clone);

                directory_clone.parent = d2;
            }
            else {

                FIle file_clone = is_FIle.clone();

                d2.children.add(file_clone);

                file_clone.parent = d2;
            }
        }
    }

    public void mv(String source, String dest_folder, Directory current_d, PrintWriter err) {

        String[] token, token2;
        boolean gasit;
        Directory d1 = current_d, d2 = current_d;
        int i;

        if (source.charAt(0) == '/') {

            while (!d1.name.equals("/")) {

                d1 = d1.parent;
            }
        }

        token2 = source.split("/");

        if (source.charAt(0) == '/' && token2.length > 0) {

            token = new String[token2.length - 1];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i + 1];
            }
        }
        else {

            token = new String[token2.length];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i];
            }
        }

        for (i = 0; i < token.length - 1; i++) {

            if (token[i].equals(".")) {

                d1 = d1;
            }
            else if (token[i].equals("..")) {

                if (d1.name.equals("/")) {

                    err.printf("mv: cannot move %s: No such file or directory\n", source);

                    return;
                }
                else {

                    d1 = d1.parent;
                }
            }
            else {

                gasit = false;

                for (Object o: d1.children) {

                    if (o instanceof Directory) {

                        if (((Directory) o).name.equals(token[i])) {

                            gasit = true;
                            d1 = (Directory) o;
                            break;
                        }
                    }
                }

                if (!gasit) {

                    err.printf("mv: cannot move %s: No such file or directory\n", source);

                    return;
                }
            }
        }

        Directory is_directory = null;
        FIle is_FIle = null;
        gasit = false;

        for (Object o: d1.children) {

            if (o instanceof Directory) {

                is_directory = (Directory) o;

                if (is_directory.name.equals(token[token.length - 1])) {

                    gasit = true;
                    is_FIle = null;
                    break;
                }
            }
            else {

                is_FIle = (FIle) o;

                if (is_FIle.name.equals(token[token.length - 1])) {

                    gasit = true;
                    is_directory = null;
                    break;
                }
            }
        }

        if (!gasit) {

            err.printf("mv: cannot move %s: No such file or directory\n", source);

            return;
        }

        if (dest_folder.charAt(0) == '/') {

            while (!d2.name.equals("/")) {

                d2 = d2.parent;
            }
        }

        token2 = dest_folder.split("/");

        if (dest_folder.charAt(0) == '/' && token2.length > 0) {

            token = new String[token2.length - 1];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i + 1];
            }
        }
        else {

            token = new String[token2.length];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i];
            }
        }

        for (i = 0; i < token.length; i++) {

            if (token[i].equals(".")) {

                d2 = d2;
            }
            else if (token[i].equals("..")) {

                if (d2.name.equals("/")) {

                    err.printf("mv: cannot move into %s: No such directory\n", dest_folder);

                    return;
                }
                else {

                    d2 = d2.parent;
                }
            }
            else {

                gasit = false;

                for (Object o: d2.children) {

                    if (o instanceof Directory) {

                        if (((Directory) o).name.equals(token[i])) {

                            gasit = true;
                            d2 = (Directory) o;
                            break;
                        }
                    }
                }

                if (!gasit) {

                    err.printf("mv: cannot move into %s: No such directory\n", dest_folder);

                    return;
                }
            }
        }

        boolean inclus = false;

        for (Object o: d2.children) {

            if (o instanceof Directory) {

                if (is_directory != null) {

                    if (((Directory) o).name.equals(is_directory.name)) {

                        inclus = true;
                        break;
                    }
                }
                else {

                    if (((Directory) o).name.equals(is_FIle.name)) {

                        inclus = true;
                        break;
                    }
                }
            }
            else {

                if (is_directory != null) {

                    if (((FIle) o).name.equals(is_directory.name)) {

                        inclus = true;
                        break;
                    }
                }
                else {

                    if (((FIle) o).name.equals(is_FIle.name)) {

                        inclus = true;
                        break;
                    }
                }
            }
        }

        if (inclus) {

            err.printf("mv: cannot move %s: Node exists at destination\n", source);
        }
        else {

            if (is_directory != null) {

                is_directory.parent.children.remove(is_directory);

                d2.children.add(is_directory);

                is_directory.parent = d2;
            }
            else {

                is_FIle.parent.children.remove(is_FIle);

                d2.children.add(is_FIle);

                is_FIle.parent = d2;
            }
        }
    }

    public void rm(String path, Directory current_d, PrintWriter err) { // !!!!!! de testat neaprat

        String[] token, token2;
        boolean gasit;
        Directory d = current_d, x = current_d;
        int i;

        if (path.charAt(0) == '/') {

            while (!d.name.equals("/")) {

                d = d.parent;
            }
        }

        token2 = path.split("/");

        if (path.charAt(0) == '/' && token2.length > 0) {

            token = new String[token2.length - 1];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i + 1];
            }
        }
        else {

            token = new String[token2.length];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i];
            }
        }

        for (i = 0; i < token.length - 1; i++) {

            if (token[i].equals(".")) {

                d = d;
            }
            else if (token[i].equals("..")) {

                if (d.name.equals("/")) {

                    err.printf("rm: cannot remove %s: No such file or directory\n", path);

                    return;
                }
                else {

                    d = d.parent;
                }
            }
            else {

                gasit = false;

                for (Object o: d.children) {

                    if (o instanceof Directory) {

                        if (((Directory) o).name.equals(token[i])) {

                            gasit = true;
                            d = (Directory) o;
                            break;
                        }
                    }
                }

                if (!gasit) {

                    err.printf("rm: cannot remove %s: No such file or directory\n", path);

                    return;
                }
            }
        }

        Directory is_directory = null;
        FIle is_FIle = null;
        gasit = false;

        for (Object o: d.children) {

            if (o instanceof Directory) {

                is_directory = (Directory) o;

                if (is_directory.name.equals(token[token.length - 1])) {

                    gasit = true;
                    is_FIle = null;
                    break;
                }
            }
            else {

                is_FIle = (FIle) o;

                if (is_FIle.name.equals(token[token.length - 1])) {

                    gasit = true;
                    is_directory = null;
                    break;
                }
            }
        }

        if (!gasit) {

            err.printf("rm: cannot remove %s: No such file or directory\n", path);

            return;
        }

        boolean inclus = false;

        if (is_directory != null) {

            while (!x.name.equals("/")) {

                if (x == is_directory) { // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

                    inclus = true;
                    break;
                }

                x = x.parent;
            }
        }

        if (!inclus) {

            if (is_directory != null) {

                is_directory.parent.children.remove(is_directory);
            }
            else {

                is_FIle.parent.children.remove(is_FIle);
            }
        }
    }

    public void touch(String file_path, Directory current_d, PrintWriter err) {

        String[] token, token2;
        boolean gasit;
        Directory d = current_d;
        StringBuilder parent_path = new StringBuilder();
        int i;

        if (file_path.charAt(0) == '/') {

            parent_path.append('/');

            while (!d.name.equals("/")) {

                d = d.parent;
            }
        }

        token2 = file_path.split("/");

        if (file_path.charAt(0) == '/' && token2.length > 0) {

            token = new String[token2.length - 1];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i + 1];
            }
        }
        else {

            token = new String[token2.length];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i];
            }
        }

        for (i = 0; i < token.length - 1; i++) {

            if (i == 0) {

                parent_path.append(token[i]);
            }
            else {

                parent_path.append('/').append(token[i]);
            }
        }

        for (i = 0; i < token.length - 1; i++) {

            if (token[i].equals(".")) {

                d = d;
            }
            else if (token[i].equals("..")) {

                if (d.name.equals("/")) {

                    err.printf("touch: %s: No such directory\n", parent_path.toString());

                    return;
                }
                else {

                    d = d.parent;
                }
            }
            else {

                gasit = false;

                for (Object o: d.children) {

                    if (o instanceof Directory) {

                        if (((Directory) o).name.equals(token[i])) {

                            gasit = true;
                            d = (Directory) o;
                            break;
                        }
                    }
                }

                if (!gasit) {

                    err.printf("touch: %s: No such directory\n", parent_path.toString());

                    return;
                }
            }
        }

        gasit = false;

        for (Object o: d.children) {

            if (o instanceof Directory) {

                if (((Directory) o).name.equals(token[token.length - 1])) {

                    gasit = true;
                    break;
                }
            }
            else {

                if (((FIle) o).name.equals(token[token.length - 1])) {

                    gasit = true;
                    break;
                }
            }
        }

        if (gasit) {

            err.printf("touch: cannot create file %s: Node exists\n",
                    parent_path.append('/').append(token[token.length - 1]).toString());
        }
        else {

            FIle new_f = new FIle(token[token.length - 1], d);

            d.children.add(new_f);
        }
    }

    public void mkdir(String folder_path, Directory current_d, PrintWriter err) {

        String[] token, token2;
        boolean gasit;
        Directory d = current_d;
        StringBuilder parent_path = new StringBuilder();
        int i;

        if (folder_path.charAt(0) == '/') {

            parent_path.append('/');

            while (!d.name.equals("/")) {

                d = d.parent;
            }
        }

        token2 = folder_path.split("/");

        if (folder_path.charAt(0) == '/' && token2.length > 0) {

            token = new String[token2.length - 1];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i + 1];
            }
        }
        else {

            token = new String[token2.length];

            for (i = 0; i < token.length; i++) {

                token[i] = token2[i];
            }
        }

        for (i = 0; i < token.length - 1; i++) {

            if (i == 0) {

                parent_path.append(token[i]);
            }
            else {

                parent_path.append('/').append(token[i]);
            }
        }

        for (i = 0; i < token.length - 1; i++) {

            if (token[i].equals(".")) {

                d = d;
            }
            else if (token[i].equals("..")) {

                if (d.name.equals("/")) {

                    err.printf("mkdir: %s: No such directory\n", parent_path.toString());

                    return;
                }
                else {

                    d = d.parent;
                }
            }
            else {

                gasit = false;

                for (Object o: d.children) {

                    if (o instanceof Directory) {

                        if (((Directory) o).name.equals(token[i])) {

                            gasit = true;
                            d = (Directory) o;
                            break;
                        }
                    }
                }

                if (!gasit) {

                    err.printf("mkdir: %s: No such directory\n", parent_path.toString());

                    return;
                }
            }
        }

        gasit = false;

        for (Object o: d.children) {

            if (o instanceof Directory) {

                if (((Directory) o).name.equals(token[token.length - 1])) {

                    gasit = true;
                    break;
                }
            }
            else {

                if (((FIle) o).name.equals(token[token.length - 1])) {

                    gasit = true;
                    break;
                }
            }
        }

        if (gasit) {

            err.printf("mkdir: cannot create directory %s: Node exists\n",
                    parent_path.append('/').append(token[token.length - 1]).toString());
        }
        else {

            Directory new_d = new Directory(token[token.length - 1], d);

            d.children.add(new_d);
        }
    }


}
