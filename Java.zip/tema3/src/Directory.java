import java.util.*;

public class Directory implements Cloneable {

    String name;
    Directory parent;
    List children;

    Directory(String name, Directory parent) {

        this.name = name;
        this.parent = parent;
        children = new ArrayList();
    }

    public Directory clone() throws CloneNotSupportedException {
        return (Directory) super.clone();
    }
}
