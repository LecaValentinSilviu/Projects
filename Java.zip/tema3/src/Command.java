public interface Command {

    void execute() throws CloneNotSupportedException;

    void change_current_directory(Directory current_d);
}
