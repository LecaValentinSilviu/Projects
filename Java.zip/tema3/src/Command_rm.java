import java.io.PrintWriter;

public class Command_rm implements Command {

    private Commands commands;
    String path;
    Directory current_d;
    PrintWriter err;

    public Command_rm(Commands commands, String path, Directory current_d, PrintWriter err) {

        this.commands = commands;
        this.path = path;
        this.current_d = current_d;
        this.err = err;
    }

    public void execute() {

        commands.rm(path, current_d, err); // argumente
    }

    public void change_current_directory(Directory current_d) {

        this.current_d = current_d;
    }
}
