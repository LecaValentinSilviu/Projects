import java.io.PrintWriter;

public class Command_cp implements Command {

    private Commands commands;
    String source, dest_folder;
    Directory current_d;
    PrintWriter err;

    public Command_cp(Commands commands, String source, String dest_folder, Directory current_d, PrintWriter err) {

        this.commands = commands;
        this.source = source;
        this.dest_folder = dest_folder;
        this.current_d = current_d;
        this.err = err;
    }

    public void execute() throws CloneNotSupportedException {

        commands.cp(source, dest_folder, current_d, err); // argumente
    }

    public void change_current_directory(Directory current_d) {

        this.current_d = current_d;
    }
}
