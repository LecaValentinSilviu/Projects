import java.io.PrintWriter;

public class Factory {

    private static Factory ourInstance = new Factory();
    Commands commands;
    Directory current_d;
    PrintWriter out, err;

    public static Factory getInstance() {
        return ourInstance;
    }

    private Factory() {}

    public void initialize(Commands commands, Directory current_d, PrintWriter out, PrintWriter err) {

        this.commands = commands;
        this.current_d = current_d;
        this.out = out;
        this.err = err;
    }

    public Command createCommand(String line) {

        Command command = null;

        String[] token = line.split(" "); // !!!!!!!!!!!!!! testeaza daca merge

        if (token[0].equals("ls")) {

            if (token.length == 1) {

                command = new Command_ls(commands, null, null, current_d, out, err);
            }

            if (token.length == 2) {

                command = new Command_ls(commands, token[1], null, current_d, out, err);
            }

            if (token.length == 3) {

                command = new Command_ls(commands, token[1], token[2], current_d, out, err);
            }
        }

        if (token[0].equals("pwd")) {

            command = new Command_pwd(commands, current_d, out);
        }

        if (token[0].equals("cd")) {

            command = new Command_cd(commands, token[1], current_d, err);
        }

        if (token[0].equals("cp")) {

            command = new Command_cp(commands, token[1], token[2], current_d, err);
        }

        if (token[0].equals("mv")) {

            command = new Command_mv(commands, token[1], token[2], current_d, err);
        }

        if (token[0].equals("rm")) {

            command = new Command_rm(commands, token[1], current_d, err);
        }

        if (token[0].equals("touch")) {

            command = new Command_touch(commands, token[1], current_d, err);
        }

        if (token[0].equals("mkdir")) {

            command = new Command_mkdir(commands, token[1], current_d, err);
        }
System.out.println(current_d.name);
        return command;
    }
}


