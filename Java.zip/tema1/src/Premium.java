public class Premium extends Basic {

    public Premium() {}

    public Premium(String nume, int nr_Basic, int nr_Premium) {

        this.nume = nume;
        this.nr_Basic = nr_Basic;
        this.nr_Premium = nr_Premium;
    }
}
