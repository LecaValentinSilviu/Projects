public class Free extends Subscriptie {

    public Free() {}
}
