public interface Cache {

    public void add(Subscriptie o);

    public void remove(int index);
}