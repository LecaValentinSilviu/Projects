public abstract class Subscriptie {

    String nume;

    int nr_Basic, nr_Premium;

    public Subscriptie() {}
}
