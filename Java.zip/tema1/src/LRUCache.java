public class LRUCache implements Cache {

    Subscriptie[] array;

    int[] timestamp;

    int current_size, max_size, contor;


    public LRUCache(int size) {

        array = new Subscriptie[size];
        timestamp = new int[size];

        for (int i = 0; i < size; i++) {

            array[i] = null;
            timestamp[i] = 0;
        }

        current_size = 0;
        max_size = size;
        contor = 0;
    }

    public void Afisare_Cache() {

        System.out.print("Cache: ");

        for (int i = 0; i < max_size;i ++) {

            if (array[i] != null) {

                System.out.print(array[i].nume + " ");
            }
            else
                System.out.print(null + " ");

        }

        System.out.print("\n");

        System.out.print("Timestamps: ");

        for (int i = 0; i < max_size; i++) {

            System.out.print(timestamp[i] + " ");
        }

        System.out.print("\n\n");
    }

    public void add(Subscriptie o) {

        if (current_size < max_size) {





            array[current_size] = o;
            contor++;
            timestamp[current_size] = contor; // timpestamp[current_size++]
            current_size++;



        }
        else {

            int min_timestamp, min_index;

            min_timestamp = contor;
            min_index = -1;

            for (int i = 0; i < max_size; i++) {

                if (min_timestamp > timestamp[i]) {

                    min_timestamp = timestamp[i];
                    min_index = i;
                }
            }

            array[min_index] = o;

            contor++;
            timestamp[min_index] = contor;
        }
    }

    public void remove(int index) {

        for (int i = index; i < current_size - 1; i++) {

            array[i] = array[i + 1];
            timestamp[i] = timestamp[i + 1];
        }

        array[current_size - 1] = null;
        timestamp[current_size - 1] = 0;
        current_size--;
    }

}
