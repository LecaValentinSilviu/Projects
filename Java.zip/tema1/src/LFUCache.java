public class LFUCache {
}
