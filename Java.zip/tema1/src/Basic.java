public class Basic extends Free {

    public Basic() {}
}
