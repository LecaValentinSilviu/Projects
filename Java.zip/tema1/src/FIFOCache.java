public class FIFOCache implements Cache {

    Subscriptie[] array;

    int current_size, max_size;

    public FIFOCache(int size) {

        array = new Subscriptie[size];

        current_size = 0;
        max_size = size;
    }

    public void Afisare_Cache() {

        System.out.print("Cache: ");

        for (int i = 0; i < max_size;i ++) {

            if (array[i] != null) {

                System.out.print(array[i].nume + " ");
            }
            else
                System.out.print(null + " ");

        }

        System.out.print("\n");
    }

    public void add(Subscriptie o) {

        if (current_size < max_size) {

            array[current_size] = o;
            current_size++;
        }
        else {

            for (int i = 0; i < max_size - 1; i++) {

                array[i] = array[i + 1];
            }

            array[max_size - 1] = o;
        }
    }

    public void remove(int index) {

        for (int i = index; i < current_size - 1; i++) {

            array[i] = array[i + 1];
        }

        array[current_size - 1] = null;
        current_size--;
    }
}
