import java.io.*;
import java.util.*;

public class Main {

    public static void main(String[] args) throws FileNotFoundException, IOException {

        File input_file = new File(args[0]); // deschidere fisier citire
        Scanner sc = new Scanner(input_file);

        FileWriter fileWriter = new FileWriter(args[1]); // deschidere fisier scriere
        PrintWriter printWriter = new PrintWriter(fileWriter);

        String type_cache = sc.next(); // citire din fisier
        int size_cache = sc.nextInt();
        int N = sc.nextInt();
        sc.nextLine();
        String line;
        String[] array_of_strings;

        Subscriptie[] memory = new Subscriptie[N]; // memoria principala
        int memory_size = 0;

        Subscriptie subscriptie; // creare subscriptie
        String nume_obiect;
        int nr_Basic, nr_Premium;

        boolean suprascris;  // variabile ajutatoare
        boolean check_memory;
        boolean check_cache;
        int get_index = -1;

        if (type_cache.equals("LRU")) {

            LRUCache cache = new LRUCache(size_cache);

            for (int i = 0; i < N; i++) {

                cache.Afisare_Cache();

                line = sc.nextLine();
                array_of_strings = line.split(" ");

                if (array_of_strings[0].equals("ADD")) {

                    nume_obiect = array_of_strings[1];
                    nr_Basic = Integer.parseInt(array_of_strings[2]);

                    if (array_of_strings.length == 3)
                        subscriptie = new Premium(nume_obiect, nr_Basic, 0);
                    else {

                        nr_Premium = Integer.parseInt(array_of_strings[3]);
                        subscriptie = new Premium(nume_obiect, nr_Basic, nr_Premium);
                    }

                    suprascris = false;
                    for (int j = 0; j < memory_size; j++) {
                        if (memory[j].nume.equals(nume_obiect)) {
                            memory[j] = subscriptie;
                            suprascris = true;
                        }
                    }

                    if (!suprascris) {

                        memory[memory_size] = subscriptie;
                        memory_size++;
                    }

                    for (int j = 0; j < cache.current_size; j++) {

                        if (cache.array[j].nume.equals(nume_obiect)) {

                            cache.remove(j);
                            break;
                        }
                    }
                }

                if (array_of_strings[0].equals("GET")) {

                    nume_obiect = array_of_strings[1];

                    check_cache = false;
                    check_memory = false;

                    for (int j = 0; j < cache.current_size; j++) {

                        if (cache.array[j].nume.equals(nume_obiect)) {

                            check_cache = true;
                            get_index = j;
                        }
                    }

                    if (check_cache) {

                        printWriter.printf("%d ", 0);

                        if (cache.array[get_index].nr_Premium > 0) {

                            printWriter.printf("Premium\n");
                            cache.array[get_index].nr_Premium--;
                        }
                        else if (cache.array[get_index].nr_Basic > 0) {

                            printWriter.printf("Basic\n");
                            cache.array[get_index].nr_Basic--;
                        }
                        else
                            printWriter.printf("Free\n");
                    }
                    else {

                        for (int j = 0; j < memory_size; j++) {

                            if (memory[j].nume.equals(nume_obiect)) {

                                check_memory = true;
                                get_index = j;
                            }
                        }

                        if (check_memory) {

                            cache.add(memory[get_index]);

                            printWriter.printf("%d ", 1);

                            if (memory[get_index].nr_Premium > 0) {

                                printWriter.printf("Premium\n");
                                memory[get_index].nr_Premium--;
                            }
                            else if (memory[get_index].nr_Basic > 0) {

                                printWriter.printf("Basic\n");
                                memory[get_index].nr_Basic--;
                            }
                            else
                                printWriter.printf("Free\n");
                        }
                        else
                            printWriter.printf("%d\n", 2);
                    }
                }
            }
        }

        if (type_cache.equals("FIFO")) {

            FIFOCache cache = new FIFOCache(size_cache);

            for (int i = 0; i < N; i++) {

                cache.Afisare_Cache();


                line = sc.nextLine();
                array_of_strings = line.split(" ");

                if (array_of_strings[0].equals("ADD")) {

                    nume_obiect = array_of_strings[1];
                    nr_Basic = Integer.parseInt(array_of_strings[2]);

                    if (array_of_strings.length == 3) {

                        subscriptie = new Premium(nume_obiect, nr_Basic, 0);
                    }
                    else {

                        nr_Premium = Integer.parseInt(array_of_strings[3]);
                        subscriptie = new Premium(nume_obiect, nr_Basic, nr_Premium);
                    }

                    suprascris = false;
                    for (int j = 0; j < memory_size; j++) {

                        if (memory[j].nume.equals(nume_obiect)) {

                            memory[j] = subscriptie;
                            suprascris = true;
                        }
                    }

                    if (!suprascris) {

                        memory[memory_size] = subscriptie;
                        memory_size++;
                    }

                    for (int j = 0; j < cache.current_size; j++) {

                        if (cache.array[j].nume.equals(nume_obiect)) {

                            cache.remove(j);
                        }
                    }
                }

                if (array_of_strings[0].equals("GET")) {

                    nume_obiect = array_of_strings[1];

                    check_cache = false;
                    check_memory = false;

                    for (int j = 0; j < cache.current_size; j++) {

                        if (cache.array[j].nume.equals(nume_obiect)) {

                            check_cache = true;
                            get_index = j;
                        }
                    }

                    if (check_cache) {

                        printWriter.printf("%d ", 0);

                        if (cache.array[get_index].nr_Premium > 0) {

                            printWriter.printf("Premium\n");
                            cache.array[get_index].nr_Premium--;
                        }
                        else if (cache.array[get_index].nr_Basic > 0) {

                            printWriter.printf("Basic\n");
                            cache.array[get_index].nr_Basic--;
                        }
                        else
                            printWriter.printf("Free\n");
                    }
                    else {

                        for (int j = 0; j < memory_size; j++) {

                            if (memory[j].nume.equals(nume_obiect)) {

                                check_memory = true;
                                get_index = j;
                            }
                        }

                        if (check_memory) {

                            cache.add(memory[get_index]);

                            printWriter.printf("%d ", 1);

                            if (memory[get_index].nr_Premium > 0) {

                                printWriter.printf("Premium\n");
                                memory[get_index].nr_Premium--;
                            }
                            else if (memory[get_index].nr_Basic > 0) {

                                printWriter.printf("Basic\n");
                                memory[get_index].nr_Basic--;
                            }
                            else
                                printWriter.printf("Free\n");
                        }
                        else
                            printWriter.printf("%d\n", 2);

                    }
                }
            }
        }

        printWriter.close();
    }
}
